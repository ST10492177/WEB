// Mobile nav toggle
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".nav-toggle");
  const list = document.getElementById("navList");
  if (toggle && list) {
    toggle.addEventListener("click", () => {
      const isOpen = list.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });
  }
});

// Hero heading fade-in
window.addEventListener("load", () => {
  const heroHeading = document.querySelector(".hero h2");
  if (heroHeading) {
    heroHeading.style.opacity = 0;
    setTimeout(() => {
      heroHeading.style.transition = "opacity 1200ms ease";
      heroHeading.style.opacity = 1;
    }, 300);
  }
});

// Simple client-side validation
function validateRequired(form) {
  const inputs = form.querySelectorAll("input[required], textarea[required], select[required]");
  let valid = true;
  inputs.forEach((input) => {
    if (!input.value.trim()) {
      input.classList.add("field-error");
      input.style.border = "2px solid #cc0000";
      valid = false;
    } else {
      input.classList.remove("field-error");
      input.style.border = "1px solid #ccc";
    }
  });
  return valid;
}

// Volunteer form
const volunteerForm = document.getElementById("volunteerForm");
if (volunteerForm) {
  volunteerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!validateRequired(volunteerForm)) {
      alert("Please fill in all required fields.");
      return;
    }
    document.getElementById("volunteerSuccess").hidden = false;
    volunteerForm.reset();
  });
}

// Sponsor form
const sponsorForm = document.getElementById("sponsorForm");
if (sponsorForm) {
  sponsorForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!validateRequired(sponsorForm)) {
      alert("Please complete all required fields.");
      return;
    }
    document.getElementById("sponsorSuccess").hidden = false;
    sponsorForm.reset();
  });
}

// Enquiry: compute response
const enquiryForm = document.getElementById("enquiryForm");
if (enquiryForm) {
  enquiryForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!validateRequired(enquiryForm)) {
      alert("Please complete all required fields.");
      return;
    }
    const type = document.getElementById("eType").value;
    let response = "";
    switch (type) {
      case "Service":
        response = "Thanks for your interest in our programs. A coordinator will contact you with schedules and availability within 2–3 business days.";
        break;
      case "Volunteer":
        response = "Great! Volunteers attend a 2-hour onboarding session. Upcoming dates: 10 Dec, 17 Dec, 7 Jan.";
        break;
      case "Sponsor":
        response = "Thank you for considering sponsorship. Our team will share impact reports and partnership tiers shortly.";
        break;
      default:
        response = "Thank you for your enquiry. We’ll respond shortly.";
    }
    const box = document.getElementById("enquiryResponse");
    const txt = document.getElementById("responseText");
    txt.textContent = response;
    box.hidden = false;
    enquiryForm.reset();
  });
}

// Contact: compile email via mailto
const contactForm = document.getElementById("contactForm");
if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!validateRequired(contactForm)) {
      alert("Please complete all required fields.");
      return;
    }
    const name = encodeURIComponent(document.getElementById("cName").value.trim());
    const email = encodeURIComponent(document.getElementById("cEmail").value.trim());
    const type = encodeURIComponent(document.getElementById("cType").value);
    const subject = encodeURIComponent(document.getElementById("cSubject").value.trim());
    const message = encodeURIComponent(document.getElementById("cMessage").value.trim());

    const body =
      `From: ${name} <${email}>\n` +
      `Type: ${type}\n` +
      `Subject: ${decodeURIComponent(subject)}\n\n` +
      `${decodeURIComponent(message)}\n\n` +
      `— Sent from BrightSteps website`;

    const mailto = `mailto:info@brightsteps.org?subject=${subject}&body=${encodeURIComponent(body)}`;
    window.location.href = mailto;
  });
}

// Lightbox gallery (programs)
const lightboxLinks = document.querySelectorAll(".lightbox");
const modal = document.getElementById("lightboxModal");
const modalImg = document.getElementById("modalImg");
const modalCaption = document.getElementById("modalCaption");
const modalClose = document.querySelector(".modal-close");

if (lightboxLinks && modal && modalImg && modalCaption && modalClose) {
  lightboxLinks.forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const src = link.getAttribute("href");
      const cap = link.getAttribute("data-caption") || "";
      modalImg.src = src;
      modalImg.alt = cap;
      modalCaption.textContent = cap;
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
    });
  });

  modalClose.addEventListener("click", () => {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    modalImg.src = "";
  });

  modal.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      modalImg.src = "";
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.classList.contains("open")) {
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
      modalImg.src = "";
    }
  });
}
